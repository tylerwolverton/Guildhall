Controls:
Right Click - walk to location ( only moves x position )
Left Click - pick up item ( just key for now )
Esc - quit the game